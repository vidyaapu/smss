﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentMngmntSystem.Teacher
{
    public partial class TeacherLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["user"] = null;
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {

            if (txtusername.Text != "" &&
                txtpassword.Text != "")
            {
                SqlConnection connection1 = new SqlConnection();
                DataTable dt = new DataTable();
                connection1.ConnectionString = "Data Source=DESKTOP-AO0976E;Initial Catalog=smss;Integrated Security=True";
                connection1.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection1;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Teacherlog";
                cmd.Parameters.AddWithValue("@UserName", SqlDbType.NVarChar).Value = txtusername.Text;
                cmd.Parameters.AddWithValue("@PassWord", SqlDbType.NVarChar).Value = txtpassword.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);






                Session["user"] = dt.Rows[0]["Teacherid"].ToString();
                Response.Redirect("../Teacher/TeacherHome.aspx");
            }
        }
    }
}