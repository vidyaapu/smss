﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace StudentMngmntSystem.Student
{
    public partial class AddStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            SqlConnection connection1 = new SqlConnection();
            connection1.ConnectionString = "Data Source=DESKTOP-AO0976E;Initial Catalog=smss;Integrated Security=True";
            connection1.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection1;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "studdtls";
            cmd.Parameters.AddWithValue("@StudName", SqlDbType.NVarChar).Value = txtname.Text;
            cmd.Parameters.AddWithValue("@StudAdd", SqlDbType.NVarChar).Value = txtadd.Text;
            cmd.Parameters.AddWithValue("@StudClass", SqlDbType.Int).Value = txtcls.Text;
            cmd.Parameters.AddWithValue("@StudDivision", SqlDbType.NVarChar).Value = ddldiv.SelectedValue;
            cmd.Parameters.AddWithValue("@StudStatus", SqlDbType.NVarChar).Value = ddlstatus.SelectedValue;
            cmd.Parameters.AddWithValue("@UserName", SqlDbType.NVarChar).Value = txtusername.Text;
            cmd.Parameters.AddWithValue("@PassWord", SqlDbType.NVarChar).Value = txtpasswrd.Text;




            cmd.ExecuteNonQuery();
            connection1.Close();
            Response.Write("<script type='text/javascript'>");
            Response.Write("alert (Add Student Successfully')");
            Response.Write("</script>");

            Response.Redirect("~/Student/StudentView.aspx");

            




        }
    }
}