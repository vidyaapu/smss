﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentMngmntSystem.Student
{
    public partial class StudentLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["user"] = null;
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            if (txtusername.Text == "Student" &&
                txtpassword.Text == "1234")
            {
                Session["user"] = "Student";
                Response.Redirect("../Student/StudentHome.aspx");
            }
        }
    }
}