﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentMngmntSystem.Teacher
{
    public partial class StudentLists : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection connection1 = new SqlConnection();
            DataTable dt = new DataTable();
            connection1.ConnectionString = "Data Source=DESKTOP-AO0976E;Initial Catalog=smss;Integrated Security=True";
            connection1.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection1;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Getstudentlist";
            cmd.Parameters.AddWithValue("@Teacherid", SqlDbType.Int).Value =Convert.ToInt32( Session["user"]);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

       
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("../Teacher/TeacherHome.aspx");
        }
    }
}