﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentMngmntSystem
{
    public partial class PrincipalLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["user"] = null;
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            if (txtusername.Text == "principal" &&
                txtpassword.Text == "1234")
            {
                Session["user"] = "principal";
                Response.Redirect("Principal/PrincipalHome.aspx");
            }
        }
    }
}