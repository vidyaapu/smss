﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentMngmntSystem.Principal
{
    public partial class PrincipalHome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection connection1 = new SqlConnection();

            connection1.ConnectionString = "Data Source=DESKTOP-AO0976E;Initial Catalog=smss;Integrated Security=True";
            connection1.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection1;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "GetAverageStudents";
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            lbl3.Text = dt.Rows[0]["StudClass"].ToString() + " - " + dt.Rows[0]["studentcount"].ToString();


            SqlConnection connection2 = new SqlConnection();

            connection2.ConnectionString = "Data Source=DESKTOP-AO0976E;Initial Catalog=smss;Integrated Security=True";
            connection2.Open();
            SqlCommand cmds = new SqlCommand();
            cmds.Connection = connection2;
            cmds.CommandType = CommandType.StoredProcedure;
            cmds.CommandText = "GetExcellentStudents";
            DataTable dt1 = new DataTable();
            SqlDataAdapter da1 = new SqlDataAdapter(cmds);
            da1.Fill(dt1);
            lbl1.Text = dt1.Rows[0]["StudClass"].ToString() + " - " + dt1.Rows[0]["studentcount"].ToString();


            SqlConnection connection3 = new SqlConnection();

            connection3.ConnectionString = "Data Source=DESKTOP-AO0976E;Initial Catalog=smss;Integrated Security=True";
            connection3.Open();
            SqlCommand cmd2 = new SqlCommand();
            cmd2.Connection = connection3;
            cmd2.CommandType = CommandType.StoredProcedure;
            cmd2.CommandText = "GetGoodStudents";
            DataTable dt2 = new DataTable();
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            da2.Fill(dt2);
            lbl2.Text = dt2.Rows[0]["StudClass"].ToString() + " - " + dt2.Rows[0]["studentcount"].ToString();


            SqlConnection connection4 = new SqlConnection();

            connection4.ConnectionString = "Data Source=DESKTOP-AO0976E;Initial Catalog=smss;Integrated Security=True";
            connection4.Open();
            SqlCommand cmd3 = new SqlCommand();
            cmd3.Connection = connection4;
            cmd3.CommandType = CommandType.StoredProcedure;
            cmd3.CommandText = "GetPoorStudents";
            DataTable dt3 = new DataTable();
            SqlDataAdapter da3 = new SqlDataAdapter(cmd3);
            da3.Fill(dt3);
            lbl4.Text = dt3.Rows[0]["StudClass"].ToString() + " - " + dt3.Rows[0]["studentcount"].ToString();








        }
    }
}