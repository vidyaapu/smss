﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentMngmntSystem.Student
{
    public partial class StudentView : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection connection1 = new SqlConnection();
            DataTable dt = new DataTable();
            connection1.ConnectionString = "Data Source=DESKTOP-AO0976E;Initial Catalog=smss;Integrated Security=True";
            connection1.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection1;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "GetStudents";
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);


            
        

        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddStudent.aspx");
        }
    }

   
    }